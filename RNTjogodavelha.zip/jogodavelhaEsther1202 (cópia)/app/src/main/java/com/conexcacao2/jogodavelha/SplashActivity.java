package com.conexcacao2.jogodavelha;

import android.app.Activity;

public class SplashActivity extends Activity {
}
